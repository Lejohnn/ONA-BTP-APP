import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { FormGroup, FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule, RouterModule, ReactiveFormsModule],
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage {
  credentialsForm: FormGroup;
  loginError: string | null = null;

  constructor(private router: Router, private authService: AuthService, private fb: FormBuilder) {
    this.credentialsForm = this.fb.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onLogin() {
    if (this.credentialsForm.valid) {
      this.authService.userLogin(this.credentialsForm).subscribe(success => {
        if (success) {
          this.router.navigate(['/tabs/projets']);
        } else {
          this.loginError = 'Identifiants invalides.';
        }
      });
    }
  }
} 