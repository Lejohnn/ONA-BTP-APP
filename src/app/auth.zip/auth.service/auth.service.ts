import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Storage } from '@ionic/storage-angular';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { FormGroup } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private odooUrl = environment.odooUrl;
  private dbName = environment.odooDb;

  constructor(private http: HttpClient, private storage: Storage) {
    this.storage.create();
  }

  userLogin(formData: FormGroup): Observable<boolean> {
    const email: string = String(formData.get('email')?.value);
    const password: string = String(formData.get('password')?.value);
    const body = {
      jsonrpc: '2.0',
      method: 'call',
      params: {
        service: 'common',
        method: 'login',
        args: [this.dbName, email, password]
      },
    };
    return new Observable<boolean>((observer) => {
      this.http.post(this.odooUrl, body).subscribe({
        next: async (response: any) => {
          const uid = response?.result;
          if (uid) {
            await this.storage.set('uid', uid);
            await this.storage.set('email', email);
            await this.storage.set('password', password);
            observer.next(true);
          } else {
            observer.next(false);
          }
          observer.complete();
        },
        error: (error) => {
          console.error('Erreur de connexion à Odoo :', error);
          observer.next(false);
          observer.complete();
        }
      });
    });
  }

  logout(): Observable<void> {
    return new Observable<void>((observer) => {
      this.storage.clear().then(() => {
        observer.next();
        observer.complete();
      }).catch((error) => {
        observer.error(error);
      });
    });
  }

  isAuthenticated(): Observable<boolean> {
    return new Observable<boolean>((observer) => {
      this.storage.get('uid').then((uid) => {
        observer.next(!!uid);
        observer.complete();
      }).catch(() => {
        observer.next(false);
        observer.complete();
      });
    });
  }

  getUid(): Observable<number | null> {
    return new Observable<number | null>((observer) => {
      this.storage.get('uid').then((uid) => {
        observer.next(uid);
        observer.complete();
      }).catch(() => {
        observer.next(null);
        observer.complete();
      });
    });
  }
} 