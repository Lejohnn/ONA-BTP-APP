import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { CapacitorHttp, HttpResponse } from '@capacitor/core';
import { Storage } from '@ionic/storage-angular';
import { environment } from 'src/environments/environment';
import { Observable, of } from 'rxjs';  // Import des Observables
import { FormGroup } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private odooUrl = environment.odooUrl;  // URL de ton serveur Odoo
  private dbName = environment.odooDb;    // Le nom de ta base de données Odoo

  constructor(private http: HttpClient, private storage: Storage) {
    this.storage.create();
  }

  /* userLogin(formData: FormGroup): Observable<boolean> {
    const codeclient: string = String(formData.get('codeclient')?.value);
    const password: string = String(formData.get('password')?.value);

    const body = {
      jsonrpc: '2.0',
      method: 'call',
      params: {
        service: 'common',
        method: 'login',
        args: [this.dbName, codeclient, password],
      }
    };

    const options = {
      url: this.odooUrl,
      headers: { 'Content-Type': 'application/json' },
      data: body
    };

    return new Observable<boolean>((observer) => {
      CapacitorHttp.post(options).then(async (response: HttpResponse) => {
        const uid = response.data?.result;

        if (uid) {
          await this.storage.set('uid', uid);
          await this.storage.set('codeclient', codeclient);
          await this.storage.set('password', password);
          observer.next(true);
        } else {
          observer.next(false);
        }
        observer.complete();
      }).catch((error) => {
        console.error('Erreur de connexion à Odoo :', error);
        observer.next(false);
        observer.complete();
      });
    });
  } */

  // Modification de la méthode login pour accepter un FormGroup
  userLogin(formData: FormGroup): Observable<boolean> {
    // Extraction des données du formulaire
    const codeclient : string = String(formData.get('codeclient')?.value);
    const password : string = String(formData.get('password')?.value);
    //console.log('Login attempt with:', { codeclient, password });

    const body = {
      jsonrpc: '2.0',
      method: 'call',
      params: {
        service: 'common',
        method: 'login',
        args: [this.dbName, codeclient, password]
      },
    };


    return new Observable<boolean>((observer) => {
      this.http.post(this.odooUrl, body).subscribe({
        next: async (response: any) => {
          const uid = response?.result;

          if (uid) {
            await this.storage.set('uid', uid);
            await this.storage.set('codeclient', codeclient);
            await this.storage.set('password', password);
            observer.next(true);
          } else {
            observer.next(false);
          }
          observer.complete();
        },
        error: (error) => {
          console.error('Erreur de connexion à Odoo :', error);
          observer.next(false);
          observer.complete();
        }
      });
    });
  }

  logout(): Observable<void> {
    return new Observable<void>((observer) => {
      this.storage.clear().then(() => {
        observer.next();
        observer.complete();
      }).catch((error) => {
        observer.error(error);
      });
    });
  }

  isAuthenticated(): Observable<boolean> {
    return new Observable<boolean>((observer) => {
      this.storage.get('uid').then((uid) => {
        observer.next(!!uid);
        observer.complete();
      }).catch(() => {
        observer.next(false);
        observer.complete();
      });
    });
  }

  getUid(): Observable<number | null> {
    return new Observable<number | null>((observer) => {
      this.storage.get('uid').then((uid) => {
        observer.next(uid);
        observer.complete();
      }).catch(() => {
        observer.next(null);
        observer.complete();
      });
    });
  }
}