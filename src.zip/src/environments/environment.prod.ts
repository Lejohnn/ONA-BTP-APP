export const environment = {
  production: true,
  odooUrl: 'https://TON_URL_ODOO', // À personnaliser
  odooDb: 'TON_NOM_BDD_ODOO'      // À personnaliser
};
