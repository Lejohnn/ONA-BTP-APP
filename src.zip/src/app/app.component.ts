import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Router } from '@angular/router';
import { addIcons } from 'ionicons';
import { home, business, card, person, list, settings } from 'ionicons/icons';

@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  imports: [IonicModule, CommonModule, RouterModule],
})
export class AppComponent {
  public appPages = [
    { title: 'Accueil', url: '/home', icon: 'home' },
    { title: 'Projets', url: '/tabs/projets', icon: 'business' },
    { title: 'Tâches', url: '/tabs/taches', icon: 'list' },
    { title: 'Caisse', url: '/tabs/caisse', icon: 'card' },
    { title: 'Paramètres', url: '/tabs/parametres', icon: 'settings' },
    { title: 'Profil', url: '/tabs/profile', icon: 'person' }
  ];

  constructor(private router: Router) {
    addIcons({ home, business, card, person, list, settings });
  }

  navigate(url: string) {
    this.router.navigate([url]);
  }
}
