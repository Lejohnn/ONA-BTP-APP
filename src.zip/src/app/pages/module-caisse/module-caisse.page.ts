import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';

interface Operation {
  montant: number;
  type: 'entrée' | 'sortie';
  date: string;
  motif: string;
}

@Component({
  selector: 'app-module-caisse',
  standalone: true,
  imports: [IonicModule, CommonModule, RouterModule],
  templateUrl: './module-caisse.page.html',
  styleUrls: ['./module-caisse.page.scss']
})
export class ModuleCaissePage implements OnInit {
  solde = 3500000; // FCFA
  operations: Operation[] = [
    { montant: 1000000, type: 'entrée', date: '2024-04-01', motif: 'Acompte client' },
    { montant: 200000, type: 'sortie', date: '2024-04-03', motif: 'Achat matériaux' },
    { montant: 500000, type: 'entrée', date: '2024-04-10', motif: 'Paiement partiel' },
    { montant: 300000, type: 'sortie', date: '2024-04-12', motif: 'Location engin' }
  ];
  projetId: string | null = null;

  constructor(private route: ActivatedRoute, private router: Router) {}

  ngOnInit() {
    this.projetId = this.route.snapshot.paramMap.get('id');
  }

  ajouterOperation() {
    // Navigation vers la page d'ajout d'opération (à implémenter)
  }

  retourProjet() {
    this.router.navigate(['/detail-projet', this.projetId]);
  }
} 