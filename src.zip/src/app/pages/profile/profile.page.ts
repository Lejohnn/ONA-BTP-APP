import { Component, OnInit } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { UserService, UserProfile } from '../../services/user.service';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [IonicModule, CommonModule],
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss']
})
export class ProfilePage implements OnInit {
  userProfile: UserProfile | null = null;
  isLoading: boolean = true;
  errorMessage: string = '';

  constructor(
    private userService: UserService,
    private toastController: ToastController
  ) {}

  ngOnInit() {
    this.loadUserProfile();
  }

  loadUserProfile(): void {
    this.isLoading = true;
    this.errorMessage = '';

    this.userService.getUserProfile().subscribe({
      next: (profile) => {
        console.log('Profil utilisateur chargé:', profile);
        this.userProfile = profile;
        this.isLoading = false;
        
        if (profile) {
          this.showToast('Profil chargé avec succès', 'success');
        } else {
          this.errorMessage = 'Impossible de charger le profil utilisateur';
          this.showToast('Erreur lors du chargement du profil', 'danger');
        }
      },
      error: (error) => {
        console.error('Erreur lors du chargement du profil:', error);
        this.errorMessage = 'Erreur lors du chargement du profil';
        this.isLoading = false;
        this.showToast('Erreur de connexion à l\'API', 'danger');
      }
    });
  }

  refreshProfile(): void {
    this.loadUserProfile();
  }

  async showToast(message: string, color: string): Promise<void> {
    const toast = await this.toastController.create({
      message: message,
      duration: 2000,
      color: color,
      position: 'top'
    });
    await toast.present();
  }
} 