import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { OfflineStorageService } from '../../services/offline-storage.service';
import { ProjetService } from '../../services/projet.service';
import { ToastController, AlertController } from '@ionic/angular';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [IonicModule, CommonModule, ReactiveFormsModule],
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss']
})
export class LoginPage implements OnInit {
  formData: FormGroup;
  isLoading: boolean = false;
  isOnline: boolean = true;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private authService: AuthService,
    private offlineStorage: OfflineStorageService,
    private projetService: ProjetService,
    private toastController: ToastController,
    private alertController: AlertController
  ) {
    this.formData = this.formBuilder.group({
      codeclient: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(1)]]
    });
  }

  ngOnInit() {
    this.checkOnlineStatus();
    this.checkCachedUser();
  }

  // ===== AUTHENTIFICATION =====
  async userLogin(): Promise<void> {
    console.log('=== DÉBUT userLogin ===');
    
    if (!this.validateFields()) {
      console.log('❌ Validation échouée');
      return;
    }

    this.isLoading = true;
    const codeclient = this.formData.get('codeclient')?.value;
    const password = this.formData.get('password')?.value;

    console.log('=== DÉBUT LOGIN ===');
    console.log('Form data:', { codeclient, password: password ? '***' : 'undefined' });
    console.log('Form valid:', this.formData.valid);

    try {
      console.log('🔍 Appel de authService.userLogin...');
      const result = await this.authService.userLogin(codeclient, password);
      
      console.log('=== RÉSULTAT AUTHENTIFICATION ===');
      console.log('Success:', result.success);
      console.log('Result:', result);
      
      if (result.success) {
        console.log('✅ Authentification réussie');
        
        // Mettre à jour l'UID dans le service projet
        if (result.uid) {
          console.log('🔧 Mise à jour UID dans projetService:', result.uid);
          this.projetService.updateUid(result.uid);
        }
        
        // Afficher le toast de bienvenue
        console.log('🎉 Affichage du toast de bienvenue...');
        await this.showWelcomeToast(result.userName || codeclient.split('@')[0]);
        
        if (result.message) {
          this.showToast(result.message, 'success');
        } else {
          this.showToast('Connexion réussie', 'success');
        }
        
        // Redirection vers la liste des projets
        console.log('🔄 Redirection vers /liste-projets...');
        this.router.navigate(['/liste-projets'], { replaceUrl: true });
      } else {
        console.log('❌ Authentification échouée');
        this.showToast(result.message || 'Échec de l\'authentification', 'danger');
      }
    } catch (error) {
      console.error('❌ Erreur lors de l\'authentification:', error);
      this.showToast('Erreur de connexion', 'danger');
    } finally {
      console.log('🏁 Fin du processus de login');
      this.isLoading = false;
    }
  }

  async showWelcomeToast(userName: string): Promise<void> {
    const toast = await this.toastController.create({
      message: `Bienvenue ${userName} ! 🎉`,
      duration: 3000,
      color: 'success',
      position: 'top',
      cssClass: 'welcome-toast',
      buttons: [
        {
          icon: 'checkmark-circle',
          side: 'start'
        }
      ]
    });
    await toast.present();
  }

  // ===== VALIDATION DES CHAMPS =====
  validateFields(): boolean {
    if (this.formData.invalid) {
      const errors = this.formData.errors;
      console.log('Form errors:', errors);
      
      if (this.formData.get('codeclient')?.hasError('required')) {
        this.showToast('Email requis', 'warning');
        return false;
      }
      
      if (this.formData.get('codeclient')?.hasError('email')) {
        this.showToast('Format d\'email invalide', 'warning');
        return false;
      }
      
      if (this.formData.get('password')?.hasError('required')) {
        this.showToast('Mot de passe requis', 'warning');
        return false;
      }
      
      if (this.formData.get('password')?.hasError('minlength')) {
        this.showToast('Mot de passe trop court', 'warning');
        return false;
      }
      
      return false;
    }
    
    return true;
  }

  // ===== GESTION STATUT CONNEXION =====
  private checkOnlineStatus(): void {
    this.offlineStorage.getOnlineStatus().subscribe(isOnline => {
      this.isOnline = isOnline;
      console.log('Statut connexion:', isOnline ? 'En ligne' : 'Hors ligne');
    });
  }

  private checkCachedUser(): void {
    this.offlineStorage.getCachedUser().then(user => {
      if (user) {
        console.log('Utilisateur en cache trouvé:', user.email);
      }
    });
  }

  // ===== UTILITAIRES UI =====
  getOnlineStatusColor(): string {
    return this.isOnline ? 'success' : 'warning';
  }

  getOnlineStatusText(): string {
    return this.isOnline ? 'En ligne' : 'Hors ligne';
  }

  // ===== NOTIFICATIONS =====
  async showToast(message: string, color: string = 'primary'): Promise<void> {
    const toast = await this.toastController.create({
      message: message,
      duration: 3000,
      color: color,
      position: 'top'
    });
    await toast.present();
  }
}
