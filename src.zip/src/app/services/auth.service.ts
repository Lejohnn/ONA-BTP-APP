import { Injectable } from '@angular/core';
import { CapacitorHttp, HttpOptions } from '@capacitor/core';
import { Observable, from, throwError } from 'rxjs';
import { retry, catchError, timeout, map } from 'rxjs/operators';
import { OfflineStorageService, CachedUser } from './offline-storage.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private odooUrl = 'https://btp.onaerp.com/jsonrpc';
  private dbName = 'btptst';
  private maxRetries = 3;
  private retryDelay = 2000;

  constructor(private offlineStorage: OfflineStorageService) {
    this.testUrlConfiguration();
  }

  // ===== AUTHENTIFICATION AVEC CACHE =====
  async userLogin(codeclient: string, password: string): Promise<{ success: boolean; uid?: number; message?: string; userName?: string }> {
    console.log('=== DÉBUT LOGIN ===');
    console.log('Form data:', { codeclient, password: password ? '***' : 'undefined' });
    console.log('Form valid:', codeclient && password);

    // Vérifier d'abord le cache local
    const cachedUser = await this.offlineStorage.getCachedUser();
    if (cachedUser && cachedUser.email === codeclient) {
      console.log('Utilisateur trouvé en cache local');
      
      // Si hors ligne, permettre la connexion avec le cache
      if (!this.offlineStorage.isCurrentlyOnline()) {
        console.log('Mode hors ligne - connexion avec cache local');
        localStorage.setItem('odoo_uid', cachedUser.uid.toString());
        return { success: true, uid: cachedUser.uid, userName: cachedUser.name };
      }
    }

    // Si en ligne, tenter l'authentification API
    if (this.offlineStorage.isCurrentlyOnline()) {
      try {
        const result = await this.authenticateWithAPI(codeclient, password);
        
        if (result.success && result.uid) {
          // Mettre en cache l'utilisateur
          const userToCache: CachedUser = {
            uid: result.uid,
            email: codeclient,
            name: result.userName || codeclient.split('@')[0], // Nom basé sur l'email
            lastLogin: new Date()
          };
          await this.offlineStorage.cacheUser(userToCache);
          
          localStorage.setItem('odoo_uid', result.uid.toString());
          return result;
        }
        
        return result;
      } catch (error) {
        console.error('Erreur lors de l\'authentification API:', error);
        
        // Si l'API échoue mais qu'on a un utilisateur en cache, permettre la connexion
        if (cachedUser && cachedUser.email === codeclient) {
          console.log('API échouée mais utilisateur en cache - connexion locale');
          localStorage.setItem('odoo_uid', cachedUser.uid.toString());
          return { success: true, uid: cachedUser.uid, message: 'Connexion en mode hors ligne', userName: cachedUser.name };
        }
        
        return { success: false, message: 'Erreur de connexion' };
      }
    } else {
      // Hors ligne sans cache valide
      return { success: false, message: 'Connexion internet requise pour la première authentification' };
    }
  }

  private async authenticateWithAPI(codeclient: string, password: string): Promise<{ success: boolean; uid?: number; message?: string; userName?: string }> {
    console.log('=== AUTHENTIFICATION DÉBUT ===');
    console.log('Login attempt with:', { codeclient, password: password ? '***' : 'undefined' });

    const requestBody = {
      jsonrpc: "2.0",
      method: "call",
      params: {
        service: "common",
        method: "login",
        args: [this.dbName, codeclient, password]
      }
    };

    console.log('Request body:', JSON.stringify(requestBody, null, 2));
    console.log('URL:', this.odooUrl);

    const options: HttpOptions = {
      url: this.odooUrl,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'User-Agent': 'ONA-BTP-Mobile/1.0'
      },
      data: requestBody,
      connectTimeout: 30000,
      readTimeout: 30000
    };

    try {
      console.log('Envoi de la requête d\'authentification...');
      const response = await CapacitorHttp.post(options);
      console.log('Réponse reçue:', response);

      if (response.status === 200 && response.data?.result) {
        const uid = response.data.result;
        console.log('✅ Authentication successful, UID:', uid);
        
        // Récupérer le nom de l'utilisateur
        const userName = await this.getUserName(uid);
        
        return { 
          success: true, 
          uid: uid,
          userName: userName || codeclient.split('@')[0] // Fallback au nom basé sur l'email
        };
      } else {
        console.error('❌ Authentication failed:', response.data);
        return { success: false, message: 'Identifiants incorrects' };
      }
    } catch (error) {
      console.error('❌ Erreur lors de l\'authentification:', error);
      const errorMessage = this.diagnoseConnectionError(error);
      return { success: false, message: errorMessage };
    }
  }

  private async getUserName(uid: number): Promise<string> {
    try {
      const requestBody = {
        jsonrpc: "2.0",
        method: "call",
        params: {
          service: "object",
          method: "execute_kw",
          args: [
            this.dbName,
            uid,
            "demo",
            "res.users",
            "search_read",
            [[["id", "=", uid]]],
            { fields: ["name"] }
          ]
        }
      };

      const options: HttpOptions = {
        url: this.odooUrl,
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'User-Agent': 'ONA-BTP-Mobile/1.0'
        },
        data: requestBody,
        connectTimeout: 10000,
        readTimeout: 10000
      };

      const response = await CapacitorHttp.post(options);
      
      if (response.status === 200 && response.data?.result && response.data.result.length > 0) {
        return response.data.result[0].name;
      }
      
      return '';
    } catch (error) {
      console.error('Erreur lors de la récupération du nom utilisateur:', error);
      return '';
    }
  }

  // ===== VÉRIFICATION AUTHENTIFICATION =====
  async isAuthenticated(): Promise<boolean> {
    const uid = localStorage.getItem('odoo_uid');
    if (!uid) return false;

    // Si hors ligne, vérifier le cache local
    if (!this.offlineStorage.isCurrentlyOnline()) {
      const cachedUser = await this.offlineStorage.getCachedUser();
      return cachedUser?.uid === parseInt(uid);
    }

    // Si en ligne, vérifier avec l'API
    try {
      const result = await this.testConnection();
      return result;
    } catch (error) {
      console.log('Erreur lors de la vérification d\'authentification:', error);
      // En cas d'erreur, utiliser le cache local
      const cachedUser = await this.offlineStorage.getCachedUser();
      return cachedUser?.uid === parseInt(uid);
    }
  }

  // ===== DÉCONNEXION =====
  async logout(): Promise<void> {
    localStorage.removeItem('odoo_uid');
    await this.offlineStorage.clearUserCache();
    console.log('Déconnexion effectuée');
  }

  // ===== GESTION DU CACHE =====
  async getCurrentUser(): Promise<CachedUser | null> {
    return await this.offlineStorage.getCachedUser();
  }

  async clearCache(): Promise<void> {
    await this.offlineStorage.clearAllCache();
  }

  // ===== MÉTHODES EXISTANTES (conservées) =====
  private async retryWithBackoff<T>(operation: (attempt: number) => Promise<T>): Promise<T> {
    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      try {
        return await operation(attempt);
      } catch (error) {
        console.log(`❌ Tentative ${attempt} échouée:`, error instanceof Error ? error.message : 'Unknown error');
        
        if (attempt === this.maxRetries) {
          throw error;
        }
        
        const delay = this.retryDelay * Math.pow(2, attempt - 1);
        console.log(`⏳ Attente de ${delay}ms avant la prochaine tentative...`);
        await this.delay(delay);
      }
    }
    throw new Error('Nombre maximum de tentatives atteint');
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private diagnoseConnectionError(error: any): string {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    const status = (error as any)?.status;
    const code = (error as any)?.code;

    if (status === 0 || code === 'NETWORK_ERROR') {
      return 'Erreur de réseau. Vérifiez votre connexion internet.';
    } else if (status === 404) {
      return 'Serveur non trouvé. Vérifiez l\'URL de l\'API.';
    } else if (status === 403) {
      return 'Accès refusé. Vérifiez vos permissions.';
    } else if (status === 500) {
      return 'Erreur serveur. Réessayez plus tard.';
    } else if (errorMessage.includes('CORS')) {
      return 'Erreur CORS. Le serveur ne permet pas les requêtes depuis cette origine.';
    } else if (errorMessage.includes('timeout')) {
      return 'Délai d\'attente dépassé. Vérifiez votre connexion.';
    } else if (errorMessage.includes('Unable to resolve host')) {
      return 'Impossible de résoudre l\'hôte. Vérifiez l\'URL.';
    } else {
      return 'Erreur de connexion inconnue. Vérifiez votre réseau et réessayez.';
    }
  }

  async testConnection(): Promise<boolean> {
    console.log('=== TEST DE CONNEXION AMÉLIORÉ ===');
    
    const testBody = {
      jsonrpc: "2.0",
      method: "call",
      params: {
        service: "common",
        method: "version"
      }
    };

    const options: HttpOptions = {
      url: this.odooUrl,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'User-Agent': 'ONA-BTP-Mobile/1.0'
      },
      data: testBody,
      connectTimeout: 15000,
      readTimeout: 15000
    };

    try {
      const response = await CapacitorHttp.post(options);
      console.log('Test de connexion réussi:', response.data);
      return true;
    } catch (error) {
      console.error('Test de connexion échoué:', error);
      return false;
    }
  }

  private testUrlConfiguration(): void {
    console.log('=== TEST CONFIGURATION URL ===');
    console.log('URL configurée:', this.odooUrl);
    console.log('Base de données:', this.dbName);
  }
} 